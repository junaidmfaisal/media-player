import { Await, data } from "react-router-dom"

const commonAPI=async(httpMethod,url,reqBody)=>{
    const reqConfig={
        method: httpMethod,
        url,
        data:reqBody
    }
    await axios(reqConfig).then(res=>{
        return res
    }).catch(err=>{
        return err
    })
}

export default commonAPI