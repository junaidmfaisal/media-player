import commonAPI from "./commonAPI"
import SERVERURL from "./serverURL"

// saveVideoAPI - use POST method, used by add component , to URL:http://localhost:3000/uploadVideos
 
export const saveVideoAPI = async (videoDetails)=>{
    return await commonAPI("POST",`${SERVERURL}/uploadVideos`,videoDetails)
}